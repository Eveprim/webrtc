import 'dart:io';

import 'package:flutter/material.dart';
import 'package:mediasoup_client_flutter/mediasoup_client_flutter.dart';
import 'package:flutter_webrtc/flutter_webrtc.dart';
import 'package:socket_io_client/socket_io_client.dart' as IO;
import 'package:protoo_client/protoo_client.dart' as ProtooClient;
import 'package:socket_io_client/socket_io_client.dart';

class MyHttpOverrides extends HttpOverrides {
  @override
  HttpClient createHttpClient(SecurityContext? context) {
    return super.createHttpClient(context)
      ..badCertificateCallback =
          (X509Certificate cert, String host, int port) =>
              true;
  }
}

void main() {
  runApp(const MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Flutter Demo',
      theme: ThemeData(
        primarySwatch: Colors.blue,
      ),
      home: const MyHomePage(title: 'Flutter Demo Home Page'),
    );
  }
}

class MyHomePage extends StatefulWidget {
  const MyHomePage({Key? key, required this.title}) : super(key: key);

  final String title;

  @override
  State<MyHomePage> createState() => _MyHomePageState();
}

class _MyHomePageState extends State<MyHomePage> {

  late IO.Socket socket;

  @override
  void initState() {
    super.initState();
    socketConnect();
  }

  Future<void> socketConnect() async {
    try {
      socket = IO.io('https://www.mediatelemedicine.tk/sfu/room',
          OptionBuilder()
              .setTransports(['websocket'])
              .build());

      socket.on('connect', (data) {
        print(socket.connected);
      });

      socket.on('connection-success', (socketId) => {
        print('done!'),
        getLocalStream()
      });
    } catch (e) {
      print(e.toString());
    }
  }

  final device = Device();
  MediaStream? _localStream;
  final RTCVideoRenderer _localRenderer = RTCVideoRenderer();
  String roomName = 'room';
  final mediaConstraints = <String, dynamic> {
    'audio': true,
    'video': {
      'width': {
        'min': 640,
        'max': 1920,
      },
      'height': {
        'min': 400,
        'max': 1080,
      }
    }
  };

  Future<void> getLocalStream() async {
    var stream = await navigator.mediaDevices.getDisplayMedia(mediaConstraints)
    .then(streamSuccess);
  }

  void streamSuccess(stream) {
    _localStream = stream;
    _localRenderer.srcObject = _localStream;
  }

  // void joinRoom() {
  //   socket.emit('joinRoom', {roomName}, (data) => {
  //     rtpCapabilities = data.rtpCapabilites;
  //   })
  // }
  //
  // void createDevice() async {
  //   await device.load(routerRtpCapabilities: rtpCapabilities)
  // }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('GetUserMedia API Test'),
        actions: [],
      ),
      body: OrientationBuilder(
        builder: (context, orientation) {
          return Center(
            child: Stack(children: <Widget>[
              Container(
                margin: EdgeInsets.fromLTRB(0.0, 0.0, 0.0, 0.0),
                width: MediaQuery.of(context).size.width,
                height: MediaQuery.of(context).size.height,
                decoration: BoxDecoration(color: Colors.black54),
                child: RTCVideoView(_localRenderer),
              )
            ]),
          );
        },
      ),
    );
  }
}
