import lib from "./build/engine.io.js";

export const { Server, Socket, Transport, transports, listen, attach, parser, protocol } = lib;
